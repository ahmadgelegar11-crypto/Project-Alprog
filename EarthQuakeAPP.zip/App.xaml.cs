﻿using Microsoft.Extensions.DependencyInjection;

namespace EarthquakeApp;

public partial class AppShell : Shell
{
    public AppShell()
    {
        InitializeComponent();

        // Cukup daftarkan FaceScanPage karena halaman ini dibuka secara relatif menggunakan navigasi push stack
        Routing.RegisterRoute("FaceScanPage", typeof(FaceScanPage));
    }
}