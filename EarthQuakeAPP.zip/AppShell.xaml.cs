﻿namespace EarthquakeApp;

public partial class App : Application
{
    public App()
    {
        InitializeComponent();

        // Baris ini yang akan memanggil AppShell untuk pertama kalinya
        MainPage = new AppShell();
    }
}