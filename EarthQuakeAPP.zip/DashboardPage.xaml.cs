using SkiaSharp;
using SQLite;
using EarthquakeApp.Models;

namespace EarthquakeApp;

public partial class DashboardPage : ContentPage
{
    private IDispatcherTimer _clockTimer;
    private SKBitmap _currentBitmap;
    private double _currentMagnitude = 0;
    private SQLiteConnection _dbConnection;
    private string _dbPath;

    public DashboardPage()
    {
        InitializeComponent();
        InitDatabase();
        LoadUserInfo();
        StartClock();
        LoadDataFromDb();
    }

    private void LoadUserInfo()
    {
        string name = Preferences.Default.Get("UserName", "User");
        string role = Preferences.Default.Get("UserRole", "Sipil");
        LblUserInfo.Text = $"{name} - {role}";
    }

    private void StartClock()
    {
        _clockTimer = Application.Current.Dispatcher.CreateTimer();
        _clockTimer.Interval = TimeSpan.FromSeconds(1);
        _clockTimer.Tick += (s, e) => { LblClock.Text = DateTime.Now.ToString("HH:mm:ss"); };
        _clockTimer.Start();
    }

    // --- LOGIKA SENSOR & PETA (SKCanvas) ---
    private void OnSimulateSensorClicked(object sender, EventArgs e)
    {
        var rnd = new Random();
        _currentMagnitude = rnd.NextDouble() * 8.0; // Random SR 0-8
        LblSensorData.Text = $"Magnitudo: {_currentMagnitude:F1} SR";
        CanvasMap.InvalidateSurface(); // Memicu ulang render kanvas peta
    }

    private void OnCanvasMapPaintSurface(object sender, SkiaSharp.Views.Maui.SKPaintSurfaceEventArgs e)
    {
        SKImageInfo info = e.Info;
        SKSurface surface = e.Surface;
        SKCanvas canvas = surface.Canvas;

        canvas.Clear(SKColors.LightGreen);

        // Menggambar koordinat gempa acak (titik episenter)
        var rnd = new Random();
        float x = rnd.Next(0, info.Width);
        float y = rnd.Next(0, info.Height);

        using SKPaint paint = new SKPaint
        {
            Style = SKPaintStyle.Fill,
            Color = SKColors.Red,
            IsAntialias = true
        };

        // Semakin besar magnitudo, semakin besar radius lingkarannya
        float radius = (float)(10 + (_currentMagnitude * 5));
        canvas.DrawCircle(x, y, radius, paint);
    }

    // --- PENGOLAHAN CITRA (SkiaSharp) ---
    private async void OnPickPhotoClicked(object sender, EventArgs e)
    {
        try
        {
            var photo = await MediaPicker.PickPhotoAsync();
            if (photo != null)
            {
                using var stream = await photo.OpenReadAsync();
                _currentBitmap = SKBitmap.Decode(stream);
                UpdateImagePreview();
            }
        }
        catch (Exception ex)
        {
            await DisplayAlert("Error", "Gagal memuat foto: " + ex.Message, "OK");
        }
    }

    private async void OnGrayscaleClicked(object sender, EventArgs e)
    {
        if (_currentBitmap == null) return;

        // Catatan: Manipulasi GetPixel/SetPixel pada bitmap resolusi tinggi akan lambat.
        // Untuk proyek nyata disarankan pointer (unsafe block) atau ColorMatrix,
        // namun untuk praktikum algoritma, looping eksplisit ini sesuai standar.

        await Task.Run(() =>
        {
            for (int y = 0; y < _currentBitmap.Height; y++)
            {
                for (int x = 0; x < _currentBitmap.Width; x++)
                {
                    SKColor c = _currentBitmap.GetPixel(x, y);

                    // Rumus Luminance (0.3*R + 0.59*G + 0.11*B)
                    byte luma = (byte)(0.3 * c.Red + 0.59 * c.Green + 0.11 * c.Blue);

                    _currentBitmap.SetPixel(x, y, new SKColor(luma, luma, luma, c.Alpha));
                }
            }
        });

        UpdateImagePreview();
    }

    private void OnAnotasiClicked(object sender, EventArgs e)
    {
        if (_currentBitmap == null) return;

        using SKCanvas canvas = new SKCanvas(_currentBitmap);
        using SKPaint paintText = new SKPaint
        {
            Color = SKColors.Red,
            TextSize = 80,
            IsAntialias = true,
            FakeBoldText = true
        };

        canvas.DrawText("AREA TERDAMPAK", 50, 100, paintText);
        UpdateImagePreview();
    }

    private void UpdateImagePreview()
    {
        if (_currentBitmap != null)
        {
            SKImage image = SKImage.FromBitmap(_currentBitmap);
            SKData data = image.Encode(SKEncodedImageFormat.Png, 100);
            Stream stream = data.AsStream();
            ImgPreview.Source = ImageSource.FromStream(() => stream);
        }
    }

    // --- DATABASE SQLITE ---
    private void InitDatabase()
    {
        _dbPath = Path.Combine(FileSystem.AppDataDirectory, "EarthquakeData.db3");
        _dbConnection = new SQLiteConnection(_dbPath);
        _dbConnection.CreateTable<EarthquakeRecord>();
    }

    private void LoadDataFromDb()
    {
        var records = _dbConnection.Table<EarthquakeRecord>().OrderByDescending(x => x.Timestamp).ToList();
        CvRecords.ItemsSource = records;
    }

    private async void OnSaveToDbClicked(object sender, EventArgs e)
    {
        string savedPhotoPath = "";

        // Simpan bitmap ke storage lokal jika ada
        if (_currentBitmap != null)
        {
            savedPhotoPath = Path.Combine(FileSystem.AppDataDirectory, $"img_{DateTime.Now.Ticks}.png");
            using SKImage image = SKImage.FromBitmap(_currentBitmap);
            using SKData data = image.Encode(SKEncodedImageFormat.Png, 100);
            using FileStream fs = File.OpenWrite(savedPhotoPath);
            data.SaveTo(fs);
        }

        var newRecord = new EarthquakeRecord
        {
            Timestamp = DateTime.Now,
            Magnitude = _currentMagnitude,
            Status = "Terdeteksi",
            PhotoPath = savedPhotoPath
        };

        _dbConnection.Insert(newRecord);
        LoadDataFromDb();
        await DisplayAlert("Sukses", "Data Telemetri berhasil diarsip.", "OK");
    }

    private void OnDeleteClicked(object sender, EventArgs e)
    {
        var button = sender as Button;
        var record = button?.CommandParameter as EarthquakeRecord;
        if (record != null)
        {
            _dbConnection.Delete(record);
            LoadDataFromDb();
        }
    }

    private void OnRecordSelected(object sender, SelectionChangedEventArgs e)
    {
        var record = e.CurrentSelection.FirstOrDefault() as EarthquakeRecord;
        if (record != null)
        {
            _currentMagnitude = record.Magnitude;
            LblSensorData.Text = $"Magnitudo: {_currentMagnitude:F1} SR (Arsip)";

            if (!string.IsNullOrEmpty(record.PhotoPath) && File.Exists(record.PhotoPath))
            {
                _currentBitmap = SKBitmap.Decode(record.PhotoPath);
                UpdateImagePreview();
            }
        }
    }

    private async void OnLogoutClicked(object sender, EventArgs e)
    {
        Preferences.Default.Clear();
        await Shell.Current.GoToAsync("//RegisterPage");
    }
}