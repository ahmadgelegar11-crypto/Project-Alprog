namespace EarthquakeApp;

[QueryProperty(nameof(UserName), "Name")]
[QueryProperty(nameof(UserRole), "Role")]
public partial class FaceScanPage : ContentPage
{
    public string UserName { get; set; }
    public string UserRole { get; set; }
    private IDispatcherTimer _timer;
    private double _progress = 0;

    public FaceScanPage()
    {
        InitializeComponent();
    }

    private async void OnStartScanClicked(object sender, EventArgs e)
    {
        BtnStart.IsEnabled = false;
        try
        {
            var status = await Permissions.CheckStatusAsync<Permissions.Camera>();
            if (status != PermissionStatus.Granted)
            {
                status = await Permissions.RequestAsync<Permissions.Camera>();
            }

            if (status == PermissionStatus.Granted)
            {
                // Implementasi kamera hardware asli via MediaPicker
                var photo = await MediaPicker.CapturePhotoAsync();
                if (photo != null)
                {
                    LblStatus.Text = "Foto berhasil diambil. Menganalisis...";
                    StartSimulationFallback(); // Lanjut ke simulasi progress
                }
                else
                {
                    StartSimulationFallback(); // Jika batal ambil foto
                }
            }
            else
            {
                LblStatus.Text = "Izin ditolak. Menggunakan Simulasi Virtual...";
                StartSimulationFallback();
            }
        }
        catch (Exception ex)
        {
            LblStatus.Text = "Kamera tidak tersedia. Mulai simulasi...";
            StartSimulationFallback();
        }
    }

    private void StartSimulationFallback()
    {
        _timer = Application.Current.Dispatcher.CreateTimer();
        _timer.Interval = TimeSpan.FromMilliseconds(200);
        _timer.Tick += (s, e) =>
        {
            _progress += 0.05; // Naik 5% per tick
            ProgBarScan.Progress = _progress;

            if (_progress >= 0.3 && _progress < 0.7) LblStatus.Text = "Memeriksa topologi wajah...";
            else if (_progress >= 0.7 && _progress < 0.9) LblStatus.Text = "Mencocokkan dengan database...";

            if (_progress >= 1.0)
            {
                _timer.Stop();
                LblStatus.Text = "Otorisasi sukses!";
                CompleteAndNavigate();
            }
        };
        _timer.Start();
    }

    private async void CompleteAndNavigate()
    {
        // Gunakan ?? "..." untuk memastikan jika nilainya null, aplikasi tidak akan crash
        Preferences.Default.Set("UserName", UserName ?? "User");
        Preferences.Default.Set("UserRole", UserRole ?? "Warga Sipil");

        await Task.Delay(1000); // Memberikan jeda waktu penulisan data ke memori lokal

        // Melakukan navigasi ke struktur akar DashboardPage
        await Shell.Current.GoToAsync("//DashboardPage");
    }
}