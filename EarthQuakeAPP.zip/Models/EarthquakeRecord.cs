﻿using SQLite;

namespace EarthquakeApp.Models;

public class EarthquakeRecord
{
    [PrimaryKey, AutoIncrement]
    public int Id { get; set; }
    public DateTime Timestamp { get; set; }
    public double Magnitude { get; set; }
    public string Status { get; set; }
    public string PhotoPath { get; set; }
}