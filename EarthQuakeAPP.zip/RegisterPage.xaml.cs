namespace EarthquakeApp;

public partial class RegisterPage : ContentPage
{
    public RegisterPage()
    {
        InitializeComponent();
    }

    private async void OnNextClicked(object sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(EntryName.Text) || string.IsNullOrWhiteSpace(EntryPassword.Text))
        {
            await DisplayAlert("Error", "Nama dan kata sandi wajib diisi.", "OK");
            return;
        }

        string role = RadioPetugas.IsChecked ? "Petugas" : "Warga Sipil";

        // Meneruskan parameter menggunakan Shell Navigation
        var navigationParameter = new Dictionary<string, object>
        {
            { "Name", EntryName.Text },
            { "Role", role }
        };

        await Shell.Current.GoToAsync("FaceScanPage", navigationParameter);
    }
}